import Form from "../component/Form";
import Header from "../component/Header";

function Todolist() {
  return (
    <div className="App">
      <Header />
      <Form />
    </div>
  );
}

export default Todolist;
