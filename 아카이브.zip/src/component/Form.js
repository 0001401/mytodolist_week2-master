import List from "./List";
import styled from "styled-components";
import { useState } from "react";
import { addTodo } from "../redux/modules/todos";
import { useDispatch, useSelector } from "react-redux";

function Form() {
  const [todo, setTodo] = useState({
    id: 0,
    title: "",
    body: "",
    isDone: false,
  });

  const onChangeHandler = (event) => {
    const { name, value } = event.target;
    setTodo({ ...todo, [name]: value });
  };

  return (
    <Box>
      <form>
        <DivBox>
          <label>Title :</label>
          <input
            type="text"
            name="title"
            onChange={onChangeHandler}
            value={todo.title}
          />
          <label>Todo :</label>
          <input
            type="text"
            name="body"
            onChange={onChangeHandler}
            value={todo.body}
          />
          <button>Add</button>
        </DivBox>
      </form>

      <List />
    </Box>
  );
}

// styled-component

const Box = styled.div`
  background-color: #e9e6e4;
  height: 80px;
  border-top: 1px solid rgba(71, 71, 71, 1);
`;

const DivBox = styled.div`
  display: flex;
  margin: 0 auto;
  justify-content: center;
  margin-top: 25px;
  & label {
    margin-left: 15px;
    margin-right: 15px;
  }
  & input {
    border: none;
    background-color: transparent;
    border-bottom: 1px solid black;
    width: 200px;
  }
  & button {
    margin-left: 150px;
    border: none;
    background-color: transparent;
  }
`;

export default Form;
