import styled from "styled-components";
import Link from "react-router-dom";
import { useSelector } from "react-redux";

function Todo() {
  const todos = useSelector((state) => state.todos);

  return (
    <div>
      <Box>
        <More>
          <a href="#!">more</a>
        </More>
        <h2>{todos[0].title}</h2>
        {console.log(todos)}
        <p>{todos[0].body}</p>
        <button>Cancel</button>
        <button>Done</button>
      </Box>
    </div>
  );
}

const Box = styled.div`
  width: 300px;
  height: 200px;
  margin-left: auto;
  margin-right: auto;
  border-radius: 10px;
  background-color: rgba(255, 255, 255, 0.4);
  & p {
    margin-left: 20px;
    font-size: 12px;
  }
  & button {
    margin-left: 60px;
    margin-top: 60px;
    border: none;
    background-color: transparent;
    border-bottom: 1px solid gray;
  }
  & h2 {
    padding-top: 15px;
    padding-left: 15px;
    padding-bottom: 15px;
    border-bottom: 1px solid gray;
    font-size: 14px;
  }
`;

const More = styled.div`
  float: right;
  margin-right: 20px;
  margin-top: 15px;
  font-size: 12px;
`;

export default Todo;
