import Todo from "./Todo";
import styled from "styled-components";

function List() {
  return (
    <div>
      <Box>
        <ul>
          <h3>a thing to do</h3>
          <Todo />
        </ul>
        <ul>
          <h3>Success!</h3>
        </ul>
      </Box>
    </div>
  );
}

const Box = styled.div`
  background-color: #e9e6e4;
  height: 700px;
  border-top: 1px solid rgba(71, 71, 71, 1);
  margin-top: 35px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  & h3 {
    text-align: center;
  }
  & ul {
    padding: 0;
  }
`;

export default List;
